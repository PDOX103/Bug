# include <iostream>
using namespace std;
# include "iGraphics.h"



#define screenWidth 1000
#define screenHeight 625
int flag=0;

/*
function iDraw() is called again and again by the system.

*/

char background[17]={"images\\Pic 1.bmp"};
char Bug[40]={"images\\Bug.bmp"};

int x=0,y=0;

int a=115, b=541;

int i=0;

void text1()
{
	iSetColor(0,255,255);
	iText(a,b,"[Inside The Border]",GLUT_BITMAP_TIMES_ROMAN_24);
}

void text2()
{
	iSetColor(255,255,255);
	iText(a,b,"[Ouside The Border]",GLUT_BITMAP_TIMES_ROMAN_24);
}

void text3()
{
	iSetColor(255,0,0);
	iText(a,b,"[Border Hit]",GLUT_BITMAP_TIMES_ROMAN_24);
}

void iDraw()
{
	//place your drawing codes here
	iClear();

	
	
	iShowBMP(0,0,background);

	
	iShowBMP2(x+100,y+100,Bug,0);

	if(flag==1)
	{
		text1();
	}
	else if(flag==2)
	{
		text3();
	}
	else
	{
		text2();
	}
		
	
	
	
}

void iPassiveMouse(int mx, int my)
{
	
}


/*
function iMouseMove() is called when the user presses and drags the mouse.
(mx, my) is the position where the mouse pointer is.
*/
void iMouseMove(int mx, int my)
{
	
	//place your codes here
	cout<<"x= "<<mx<<" y= "<<my<<endl;
	x=mx-120;
	y=my-145;

	

	if(mx>=304 && mx<=690 && my>=222 && my<=430)
	{
		flag=1;
	}
	else if(mx>=251 && mx<=742 && my>=170 && my<=482)
	{
		flag=2;
	}
	else
		flag=3;

}

/*
function iMouse() is called when the user presses/releases the mouse.
(mx, my) is the position where the mouse pointer is.
*/
void iMouse(int button, int state, int mx, int my)
{
	if (button == GLUT_LEFT_BUTTON && state == GLUT_DOWN)
	{
		
	}
	if (button == GLUT_RIGHT_BUTTON && state == GLUT_DOWN)
	{
		//place your codes here

	}
}

/*
function iKeyboard() is called whenever the user hits a key in keyboard.
key- holds the ASCII value of the key pressed.
*/
void iKeyboard(unsigned char key)
{
	if (key == 'q')
	{
		exit(0);
	}

	//place your codes for other keys here
}

/*
function iSpecialKeyboard() is called whenver user hits special keys like-
function keys, home, end, pg up, pg down, arraows etc. you have to use
appropriate constants to detect them. A list is:
GLUT_KEY_F1, GLUT_KEY_F2, GLUT_KEY_F3, GLUT_KEY_F4, GLUT_KEY_F5, GLUT_KEY_F6,
GLUT_KEY_F7, GLUT_KEY_F8, GLUT_KEY_F9, GLUT_KEY_F10, GLUT_KEY_F11, GLUT_KEY_F12,
GLUT_KEY_LEFT, GLUT_KEY_UP, GLUT_KEY_RIGHT, GLUT_KEY_DOWN, GLUT_KEY_PAGE UP,
GLUT_KEY_PAGE DOWN, GLUT_KEY_HOME, GLUT_KEY_END, GLUT_KEY_INSERT
*/
void iSpecialKeyboard(unsigned char key)
{

	if (key == GLUT_KEY_UP)
	{
		y=y+10;
	}
	if (key == GLUT_KEY_DOWN)
	{
		y=y-10;
	}
	if (key == GLUT_KEY_RIGHT)
	{
		x=x+10;
	}
	if (key == GLUT_KEY_LEFT)
	{
		x=x-10;
	}
	//place your codes for other keys here
}

int main()
{
	//place your own initialization codes here.

	
	iInitialize(screenWidth, screenHeight, "FLY");



	iStart(); // it will start drawing

	return 0;
}

